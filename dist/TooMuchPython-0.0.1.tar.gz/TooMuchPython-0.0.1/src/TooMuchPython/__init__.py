print('Hello World! (if you see this then this work)')

def magic(n):
    return n + 1