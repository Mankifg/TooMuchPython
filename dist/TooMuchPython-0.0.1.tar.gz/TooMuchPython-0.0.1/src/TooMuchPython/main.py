def magic(n):
    return n + 1